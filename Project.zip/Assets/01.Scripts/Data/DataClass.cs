using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataClass : MonoBehaviour
{
    public int sword;
    public int swordMax;

    public int gold;
    public int cash;





}
